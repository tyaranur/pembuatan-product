<?PHP 
//Mengatur data koneksi
$host ="localhost"; //Alamat server My SQL (biasanya localhost)
$user = "root";// Username MySQL (default; root)
$pass = ""; // password Mysql (default ; kosong)
$dbname = "belajar_php_kelasc"; // Nama database

// Membuat koneksi
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Cek apakah koneksi berhasil
if (!$conn) {
    die("koneksi error:" . mysqli_connect_error());
}
echo "koneksi SUCCESS!";
?>