<?php
//memeriksa apakah data telah di submit
if (isset($_POST['username'])) {
    //mengambil data dari formulir
    $uname = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $nmlengkap = htmlspecialchars($_POST['nama_lengkap']);
    $password = htmlspecialchars($_POST['password']);
    //$harga = htmlspecialchars($_POST['harga']);
    /*$diskon = htmlspecialchars($_POST['diskon']); */

    //Memproses array barang dan jumlah
    $barang = isset($_POST['barang']) ? $_POST['barang'] : [];  // Array produk yang di pilih
    $jumlah = isset($_POST['jumlah']) ? $_POST['jumlah'] : array(); // Array jumlah produk 

    $jeksonbarang = json_encode($barang);
    //Menghubungkan ke file koneksi.php
    include 'koneksityara.php';

    $id = htmlspecialchars($_POST['id']);
    if(!empty($id)){
        // Query untuk memperbarui data
    $sql = "UPDATE transaksi SET nama = '$username', email = '$email', nama_lengkap = '$nama_lengkap', password = '$password', data_barang = '$json_barang' WHERE id = '$id'";
    }else{
        //Query untuk menyimpan data 
    }
    $sql = "INSERT INTO transaksi (nama, email, nama_lengkap, password, data_barang) VALUES ('$uname', '$email', '$nmlengkap', '$password', '$jeksonbarang')";

    //Menjalankan Query
    if (mysqli_query($conn, $sql)){
        echo "Data berhasil disimpan!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Menutup koneksi 
    mysqli_close($conn);

    // Tampilan data dalam format invoice yang lebih menarik
    $tampil = "
    <style>
        body { font-family: 'Courier New', Courier, monospace; font-size: 14px; background-color: #f4f4f9; color: #333; margin: 0; padding: 0; }
        .invoice { width: 100%; max-width: 600px; margin: 20px auto; padding: 20px; background: #fff; border-radius: 8px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); }
        h2 { text-align: center; font-size: 24px; margin-bottom: 20px; color: #007BFF; }
        .content { margin: 20px 0; }
        .item { margin: 10px 0; font-size: 16px; }
        .footer { text-align: center; margin-top: 20px; font-style: italic; color: #666; }
        .line { border-top: 2px solid #007BFF; margin: 20px 0; }
        .header { text-align: center; margin-bottom: 20px; }
        .logo { font-size: 28px; font-weight: bold; color: #007BFF; }
        .separator { margin: 10px 0; border-bottom: 2px solid #007BFF; }
        .product-list { margin-top: 20px; font-size: 16px; }
        .product-item { margin: 10px 0; }
        .product-item strong { color: #007BFF; }
    </style>
    <div class='invoice'>
        <div class='header'>
            <div class='logo'>KASIR SEDERHANA</div>
            <div class='separator'></div>
            <h2>INVOICE</h2>
        </div>
        <div class='content'>
            <div class='item'><strong>NIM:</strong> 23050574</div>
            <div class='item'><strong>Nama Anda:</strong> Tyara</div>
            <div class='item'><strong>Username:</strong> ".$uname."</div>
            <div class='item'><strong>Nama Lengkap:</strong> ".$nmlengkap."</div>
            <div class='item'><strong>Email:</strong> ".$email."</div>
            <div class='item'><strong>Password:</strong> ".$password."</div>
        </div>
        <div class='line'></div>
        <div class='product-list'>
            <h3>Produk yang Dipilih:</h3>";
            
            if (!empty($barang)) {
                foreach ($barang as $key => $product) {
                    $product_quantity = $jumlah[$key]; // jumlah produk yang dipilih
                    $tampil .= "<div class='product-item'><strong>".$product.":</strong> ".$product_quantity." item(s)</div>";
                }
            } else {
                $tampil .= "<div class='product-item'>Tidak ada barang yang dipilih.</div>";
            }

    $tampil .= "
        </div>
        <div class='line'></div>
        <div class='footer'>
            Terima kasih atas kepercayaan Anda! <br> Kami sangat menghargai partisipasi Anda.
        </div>
    </div>";

} else {
    $tampil = "<p style='text-align:center; font-size: 20px;'>Data tidak di-submit</p>";
}

echo $tampil;
?>
