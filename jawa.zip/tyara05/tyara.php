<form action = "tyara2.php" method ="post" onsubmit="return validateform()">
<input type="hidden" name= "id" value="<?php if(!empty($data['id'])){ echo $data['id'];} ?>">
<table>
    
    <tr>
        <td>username</td>
        <td>:</td>
        <td><input type="text" name="username"required value="<?php if(!empty($data['nama'])){echo $data['nama']; } ?>"> </td>
    </tr>
    <tr>
        <td>nama lengkap </td>
        <td>:</td>
        <td><input type="text" name="nama lengkap"required value="<?php if(!empty($data['nama lengkap'])){echo $data['nama lengkap']; } ?>"> </td>
    </tr>
    <tr>
        <td style="color: red;">email</td>
        <td>:</td>
        <td><input type="email" id="email" name="email"required value="<?php if(!empty($data['email'])){echo $data['email']; } ?>"> </td>
    </tr>
    <tr>
        <td>password</td>
        <td>:</td>
        <td><input type="password" id="password" name="password" required value="<?php if(!empty($data['password'])){echo $data['password']; } ?>"> </td>
    </tr>

    <?php
      //Decode data barang terpilih
      $data_barang_terpilih = (!empty($data['data_barang'])) ? json_decode($data['data_barang'], true) : array();
    ?>

    <!-- checkbox dan input jumlah untuk barang -->
    <tr> 
           <td style="color:black; font-size:40px;">barang</td>
           <td style="color:black; font-size:40px;">:</td>
           <td>
             <div>
                <input type="checbox" name="barang[]" value="sapu - Rp20.000" id="sapu" <?php echo in_array("sapu - Rp20.000", $data_barang_terpilih) ? 'checked' : ''; ?>>
                <label for="sapu">sapu - Rp20.000</label>
                <input type="number" name="jumlah[]" placeholder="jumlah" min="2" style="width:50px;">

           </div>
           <div>
           <input type="checbox" name="barang[]" value="sapulidi - Rp10.000" id="sapulidi <?php echo in_array("sapulidi - Rp10.000", $data_barang_terpilih) ? 'checked' : ''; ?>>
                <label for="sapulidi">sapulidi - Rp10.000</label>
                <input type="number" name="jumlah[]" placeholder="jumlah" min="2" style="width:50px;" >
        <div> 
        <input type="checbox" name="barang[]" value="pengki - Rp15.000" id="pengki" <?php echo in_array("pengki - Rp15.000", $data_barang_terpilih) ? 'checked' : ''; ?>>
                <label for="pengki">pengki - Rp15.000</label>
                <input type="number" name="jumlah[]" placeholder="jumlah" min="2" style="width:50px;">
    <tr>
     <td>harga</td>
     <td>:</td>
     <td><input type="text" id="harga"  required></td>
    </tr>
    <tr>
     <td>diskon</td>
     <td>:</td>
     <td><input type="diskon" id="diskon" name="diskon" required></td>
    </tr>
    </tr>

        <td></td>
        <td><input type ="submit" value="submit"></td>
    </tr>
</table>
</form>
<script>
  function validateform() {
    var password = document.getElementById("password").value;
    if (password.length < 6) {
        alert("password harus memiliki minimal 6 karakter");
        return false;
    }
    return true;
}
</script>